#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	GLfloat getXChange();
	GLfloat getYChange();
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	GLfloat getrotay() { return rotay; }
	GLfloat getrotax() { return rotax; }
	GLfloat getrotaz() { return rotaz; }
	GLfloat getarticulacion1() { return articulacion1; }
	GLfloat getarticulacion2() { return articulacion2; }
	GLfloat getarticulacion3() { return articulacion3; }
	GLfloat getarticulacion4() { return articulacion4; }
	GLfloat getarticulacion5() { return articulacion5; }
	GLfloat getarticulacion6() { return articulacion6; }
	

	// Llanta
	GLfloat getWheel1Rotation() { return wheel1Rotation; }
	GLfloat getWheel2Rotation() { return wheel2Rotation; }
	GLfloat getWheel3Rotation() { return wheel3Rotation; }
	GLfloat getWheel4Rotation() { return wheel4Rotation; }

	//Perro

	GLfloat getLeg1UpperRotation() { return leg1UpperRotation; }
	GLfloat getLeg1LowerRotation() { return leg1LowerRotation; }
	GLfloat getLeg2UpperRotation() { return leg2UpperRotation; }
	GLfloat getLeg2LowerRotation() { return leg2LowerRotation; }
	GLfloat getLeg3UpperRotation() { return leg3UpperRotation; }
	GLfloat getLeg3LowerRotation() { return leg3LowerRotation; }
	GLfloat getLeg4UpperRotation() { return leg4UpperRotation; }
	GLfloat getLeg4LowerRotation() { return leg4LowerRotation; }
	GLfloat getLeftEarRotation() { return leftEarRotation; }
	GLfloat getRightEarRotation() { return rightEarRotation; }
	GLfloat getTailRotation() { return tailRotation; }
	GLfloat getHeadYaw() { return headYaw; }
	GLfloat getHeadPitch() { return headPitch; }
	GLfloat getHeadRoll() { return headRoll; }


	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	GLfloat rotax,rotay,rotaz, articulacion1, articulacion2, articulacion3, articulacion4, articulacion5, articulacion6,wheel1Rotation, wheel2Rotation, wheel3Rotation, wheel4Rotation;
	
	// Leg articulation angles
	GLfloat leg1UpperRotation = 0.0f;
	GLfloat leg1LowerRotation = 0.0f;
	GLfloat leg2UpperRotation = 0.0f;
	GLfloat leg2LowerRotation = 0.0f;
	GLfloat leg3UpperRotation = 0.0f;
	GLfloat leg3LowerRotation = 0.0f;
	GLfloat leg4UpperRotation = 0.0f;
	GLfloat leg4LowerRotation = 0.0f;
	GLfloat leftEarRotation = 0.0f;
	GLfloat rightEarRotation = 0.0f;
	GLfloat tailRotation = 0.0f;

	GLfloat headYaw = 0.0f;   
	GLfloat headPitch = 0.0f; 
	GLfloat headRoll = 0.0f;  



	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	bool mouseFirstMoved;
	void createCallbacks();
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);
};

