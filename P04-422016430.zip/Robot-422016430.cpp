/*Pr�ctica 4: Modelado Jer�rquico.
Se implementa el uso de matrices adicionales para almacenar informaci�n de transformaciones geom�tricas que se quiere
heredar entre diversas instancias para que est�n unidas
Teclas de la F a la K para rotaciones de articulaciones
*/
#include <stdio.h>
#include <string.h>
#include<cmath>
#include<vector>
#include <glew.h>
#include <glfw3.h>
//glm
#include<glm.hpp>
#include<gtc\matrix_transform.hpp>
#include<gtc\type_ptr.hpp>
#include <gtc\random.hpp>
//clases para dar orden y limpieza al c�digo
#include"Mesh.h"
#include"Shader.h"
#include"Sphere.h"
#include"Window.h"
#include"Camera.h"
//tecla E: Rotar sobre el eje X
//tecla R: Rotar sobre el eje Y
//tecla T: Rotar sobre el eje Z
using std::vector;
//Dimensiones de la ventana
const float toRadians = 3.14159265f / 180.0; //grados a radianes
const float PI = 3.14159265f;
GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;
static double limitFPS = 1.0 / 60.0;
Camera camera;
Window mainWindow;
vector<Mesh*> meshList;
vector<Shader>shaderList;
//Vertex Shader
static const char* vShader = "shaders/shader.vert";
static const char* fShader = "shaders/shader.frag";
Sphere sp = Sphere(1.0, 20, 20); //recibe radio, slices, stacks

void CrearCubo()
{
	unsigned int cubo_indices[] = {
		// front
		0, 1, 2,
		2, 3, 0,
		// right
		1, 5, 6,
		6, 2, 1,
		// back
		7, 6, 5,
		5, 4, 7,
		// left
		4, 0, 3,
		3, 7, 4,
		// bottom
		4, 5, 1,
		1, 0, 4,
		// top
		3, 2, 6,
		6, 7, 3
	};

	GLfloat cubo_vertices[] = {
		// front
		-0.5f, -0.5f,  0.5f,
		0.5f, -0.5f,  0.5f,
		0.5f,  0.5f,  0.5f,
		-0.5f,  0.5f,  0.5f,
		// back
		-0.5f, -0.5f, -0.5f,
		0.5f, -0.5f, -0.5f,
		0.5f,  0.5f, -0.5f,
		-0.5f,  0.5f, -0.5f
	};
	Mesh* cubo = new Mesh();
	cubo->CreateMesh(cubo_vertices, cubo_indices, 24, 36);
	meshList.push_back(cubo);
}

// Pir�mide triangular regular
void CrearPiramideTriangular()
{
	unsigned int indices_piramide_triangular[] = {
			0,1,2,
			1,3,2,
			3,0,2,
			1,0,3

	};
	GLfloat vertices_piramide_triangular[] = {
		-0.5f, -0.5f,0.0f,	//0
		0.5f,-0.5f,0.0f,	//1
		0.0f,0.5f, -0.25f,	//2
		0.0f,-0.5f,-0.5f,	//3

	};
	Mesh* obj1 = new Mesh();
	obj1->CreateMesh(vertices_piramide_triangular, indices_piramide_triangular, 12, 12);
	meshList.push_back(obj1);

}
/*
Crear cilindro y cono con arreglos din�micos vector creados en el Semestre 2023 - 1 : por S�nchez P�rez Omar Alejandro
*/
void CrearCilindro(int res, float R) {

	//constantes utilizadas en los ciclos for
	int n, i;
	//c�lculo del paso interno en la circunferencia y variables que almacenar�n cada coordenada de cada v�rtice
	GLfloat dt = 2 * PI / res, x, z, y = -0.5f;

	vector<GLfloat> vertices;
	vector<unsigned int> indices;

	//ciclo for para crear los v�rtices de las paredes del cilindro
	for (n = 0; n <= (res); n++) {
		if (n != res) {
			x = R * cos((n)*dt);
			z = R * sin((n)*dt);
		}
		//caso para terminar el c�rculo
		else {
			x = R * cos((0) * dt);
			z = R * sin((0) * dt);
		}
		for (i = 0; i < 6; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(y);
				break;
			case 2:
				vertices.push_back(z);
				break;
			case 3:
				vertices.push_back(x);
				break;
			case 4:
				vertices.push_back(0.5);
				break;
			case 5:
				vertices.push_back(z);
				break;
			}
		}
	}

	//ciclo for para crear la circunferencia inferior
	for (n = 0; n <= (res); n++) {
		x = R * cos((n)*dt);
		z = R * sin((n)*dt);
		for (i = 0; i < 3; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(-0.5f);
				break;
			case 2:
				vertices.push_back(z);
				break;
			}
		}
	}

	//ciclo for para crear la circunferencia superior
	for (n = 0; n <= (res); n++) {
		x = R * cos((n)*dt);
		z = R * sin((n)*dt);
		for (i = 0; i < 3; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(0.5);
				break;
			case 2:
				vertices.push_back(z);
				break;
			}
		}
	}

	//Se generan los indices de los v�rtices
	for (i = 0; i < vertices.size(); i++) indices.push_back(i);

	//se genera el mesh del cilindro
	Mesh* cilindro = new Mesh();
	cilindro->CreateMeshGeometry(vertices, indices, vertices.size(), indices.size());
	meshList.push_back(cilindro);
}

//funci�n para crear un cono
void CrearCono(int res, float R) {

	//constantes utilizadas en los ciclos for
	int n, i;
	//c�lculo del paso interno en la circunferencia y variables que almacenar�n cada coordenada de cada v�rtice
	GLfloat dt = 2 * PI / res, x, z, y = -0.5f;

	vector<GLfloat> vertices;
	vector<unsigned int> indices;

	//caso inicial para crear el cono
	vertices.push_back(0.0);
	vertices.push_back(0.5);
	vertices.push_back(0.0);

	//ciclo for para crear los v�rtices de la circunferencia del cono
	for (n = 0; n <= (res); n++) {
		x = R * cos((n)*dt);
		z = R * sin((n)*dt);
		for (i = 0; i < 3; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(y);
				break;
			case 2:
				vertices.push_back(z);
				break;
			}
		}
	}
	vertices.push_back(R * cos(0) * dt);
	vertices.push_back(-0.5);
	vertices.push_back(R * sin(0) * dt);


	for (i = 0; i < res + 2; i++) indices.push_back(i);

	//se genera el mesh del cono
	Mesh* cono = new Mesh();
	cono->CreateMeshGeometry(vertices, indices, vertices.size(), res + 2);
	meshList.push_back(cono);
}

//funci�n para crear pir�mide cuadrangular unitaria
void CrearPiramideCuadrangular()
{
	vector<unsigned int> piramidecuadrangular_indices = {
		0,3,4,
		3,2,4,
		2,1,4,
		1,0,4,
		0,1,2,
		0,2,4

	};
	vector<GLfloat> piramidecuadrangular_vertices = {
		0.5f,-0.5f,0.5f,
		0.5f,-0.5f,-0.5f,
		-0.5f,-0.5f,-0.5f,
		-0.5f,-0.5f,0.5f,
		0.0f,0.5f,0.0f,
	};
	Mesh* piramide = new Mesh();
	piramide->CreateMeshGeometry(piramidecuadrangular_vertices, piramidecuadrangular_indices, 15, 18);
	meshList.push_back(piramide);
}



void CreateShaders()
{
	Shader* shader1 = new Shader();
	shader1->CreateFromFiles(vShader, fShader);
	shaderList.push_back(*shader1);

}


int main()
{
	mainWindow = Window(800, 600);
	mainWindow.Initialise();
	//Cilindro y cono reciben resoluci�n (slices, rebanadas) y Radio de circunferencia de la base y tapa

	CrearCubo();//�ndice 0 en MeshList
	CrearCilindro(30, 1.0f);//�ndice 1 en MeshList
	CrearCono(25, 2.0f);//�ndice 2 en MeshList
	CrearPiramideTriangular();//�ndice 3 en MeshList
	CrearPiramideCuadrangular();//�ndice 4 en MeshList
	sp.init();          
	sp.load();          
	CreateShaders();

    camera = Camera(glm::vec3(0.0f, 3.0f, 10.0f), glm::vec3(0.0f, 1.0f, 0.0f), -90.0f, 0.0f, 0.5f, 0.5f);

  
    glm::mat4 projection = glm::perspective(glm::radians(60.0f), mainWindow.getBufferWidth() / mainWindow.getBufferHeight(), 0.1f, 100.0f);

    // Uniforme
    GLuint uniformModel = 0;
    GLuint uniformProjection = 0;
    GLuint uniformView = 0;
    GLuint uniformColor = 0;

    // Main  
    while (!mainWindow.getShouldClose()) {
       
        GLfloat now = glfwGetTime();
        deltaTime = now - lastTime;
        deltaTime += (now - lastTime) / limitFPS;
        lastTime = now;

        glfwPollEvents();
        camera.keyControl(mainWindow.getsKeys(), deltaTime);
        camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());

        // Limpiar
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //Shader
        shaderList[0].useShader();
        uniformModel = shaderList[0].getModelLocation();
        uniformProjection = shaderList[0].getProjectLocation();
        uniformView = shaderList[0].getViewLocation();
        uniformColor = shaderList[0].getColorLocation();

        glm::mat4 model(1.0);
        glm::mat4 modelaux(1.0);
        glm::vec3 color(1.0f, 1.0f, 1.0f);

        // Cuerpo
        model = glm::translate(model, glm::vec3(0.0f, 1.2f, 0.0f));
        modelaux = model;  
        model = glm::scale(model, glm::vec3(2.0f, 0.8f, 3.0f));
        color = glm::vec3(0.6f, 0.6f, 0.8f); // azul/grisoso
        glUniform3fv(uniformColor, 1, glm::value_ptr(color));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
        glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));
        meshList[0]->RenderMesh(); // prisma rectangular

        // Cuello(Articulaci�n)
        model = modelaux;
        model = glm::translate(model, glm::vec3(0.0f, 0.4f, 1.0f)); // Cuello
        
        // Rotaciones Cabeza
        model = glm::rotate(model, glm::radians(mainWindow.getHeadYaw()), glm::vec3(0.0f, 1.0f, 0.0f));  
        model = glm::rotate(model, glm::radians(mainWindow.getHeadPitch()), glm::vec3(1.0f, 0.0f, 0.0f));  
        model = glm::rotate(model, glm::radians(mainWindow.getHeadRoll()), glm::vec3(0.0f, 0.0f, 1.0f)); 
        
        modelaux = model;  
        
        // Cabeza
        model = glm::translate(model, glm::vec3(0.0f, 0.2f, 0.3f)); 
        model = glm::scale(model, glm::vec3(1.2f, 1.0f, 1.0f));
        color = glm::vec3(0.7f, 0.7f, 0.9f);  
        glUniform3fv(uniformColor, 1, glm::value_ptr(color));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        meshList[0]->RenderMesh();  

        // Ojos
        for (int i = -1; i <= 1; i += 2) {
            model = modelaux;
            model = glm::translate(model, glm::vec3(i * 0.3f, 0.3f, 0.8f));
            model = glm::scale(model, glm::vec3(0.15f, 0.15f, 0.15f));
            color = glm::vec3(0.1f, 0.1f, 0.1f); // NEGRO
            glUniform3fv(uniformColor, 1, glm::value_ptr(color));
            glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
            sp.render(); 
        }

	


        // Nariz
        model = modelaux;
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.8f));
        model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
        color = glm::vec3(0.65f, 0.65f, 0.85f);
        glUniform3fv(uniformColor, 1, glm::value_ptr(color));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        meshList[0]->RenderMesh(); 

        // Punta Nariz
        model = modelaux;
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, glm::vec3(0.2f, 0.2f, 0.2f));
        color = glm::vec3(0.1f, 0.1f, 0.1f);  
        glUniform3fv(uniformColor, 1, glm::value_ptr(color));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        sp.render();  

        // Oreja Izquierda 
        model = modelaux;
        model = glm::translate(model, glm::vec3(-0.4f, 0.8f, 0.0f));
        model = glm::rotate(model, glm::radians(mainWindow.getLeftEarRotation()), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.3f, 0.5f, 0.2f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        color = glm::vec3(0.8f, 0.5f, 0.8f); // Morado rosa
        glUniform3fv(uniformColor, 1, glm::value_ptr(color));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        meshList[3]->RenderMesh(); // Piramide

        // Oreja Derecha
        model = modelaux;
        model = glm::translate(model, glm::vec3(0.5f, 0.8f, 0.0f));
        model = glm::rotate(model, glm::radians(-1 * mainWindow.getRightEarRotation()), glm::vec3(0.0f, 1.0f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));  

        model = glm::scale(model, glm::vec3(0.3f, 0.5f, 0.2f));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        meshList[3]->RenderMesh();  

        // Cola
        model = glm::mat4(1.0);
        model = glm::translate(model, glm::vec3(0.0f, 1.4f, -1.5f));  
        model = glm::rotate(model, glm::radians(mainWindow.getTailRotation()), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.2f, 0.2f, 1.2f));
        color = glm::vec3(0.6f, 0.6f, 0.8f);  
        glUniform3fv(uniformColor, 1, glm::value_ptr(color));
        glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
        meshList[1]->RenderMeshGeometry();  

        // Piernas
        float legOffsets[4][2] = {
            {-0.8f, 1.2f},  // Enfrente-Izquierda
            {0.8f, 1.2f},   // Enfrente-Derecha
            {-0.8f, -1.2f}, // Atras-Izquierda
            {0.8f, -1.2f}   // Atras-Derecha
        };

        for (int i = 0; i < 4; i++) {
            // Articulaciones de arriba
            model = glm::mat4(1.0);
            model = glm::translate(model, glm::vec3(legOffsets[i][0], 1.0f, legOffsets[i][1]));

            // Articulaciones de arriba
            float upperRotation = 0.0f;
            switch (i) {
            case 0: upperRotation = mainWindow.getLeg1UpperRotation(); break;
            case 1: upperRotation = mainWindow.getLeg2UpperRotation(); break;
            case 2: upperRotation = mainWindow.getLeg3UpperRotation(); break;
            case 3: upperRotation = mainWindow.getLeg4UpperRotation(); break;
            }

            model = glm::rotate(model, glm::radians(upperRotation), glm::vec3(1.0f, 0.0f, 0.0f));
            modelaux = model;  

            // Parte de arriba
            model = glm::translate(model, glm::vec3(0.0f, -0.5f, 0.0f));
            model = glm::scale(model, glm::vec3(0.3f, 1.0f, 0.3f));
            color = glm::vec3(0.5f, 0.5f, 0.7f);  
            glUniform3fv(uniformColor, 1, glm::value_ptr(color));
            glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
            meshList[1]->RenderMeshGeometry(); //Cilindro

            // Articulaciones bajas
            model = modelaux;
            model = glm::translate(model, glm::vec3(0.0f, -1.0f, 0.0f));

            
            float lowerRotation = 0.0f;
            switch (i) {
            case 0: lowerRotation = mainWindow.getLeg1LowerRotation(); break;
            case 1: lowerRotation = mainWindow.getLeg2LowerRotation(); break;
            case 2: lowerRotation = mainWindow.getLeg3LowerRotation(); break;
            case 3: lowerRotation = mainWindow.getLeg4LowerRotation(); break;
            }

            model = glm::rotate(model, glm::radians(lowerRotation), glm::vec3(1.0f, 0.0f, 0.0f));

            // Parte de abajo
            model = glm::translate(model, glm::vec3(0.0f, -0.5f, 0.0f));
            model = glm::scale(model, glm::vec3(0.25f, 1.0f, 0.25f));
            color = glm::vec3(0.4f, 0.4f, 0.6f);  
            glUniform3fv(uniformColor, 1, glm::value_ptr(color));
            glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
            meshList[1]->RenderMeshGeometry();  

            // Patas
            model = glm::translate(model, glm::vec3(0.0f, -0.5f, 0.1f));
            model = glm::scale(model, glm::vec3(1.5f, 0.2f, 1.5f));
            color = glm::vec3(0.3f, 0.3f, 0.5f);  
            glUniform3fv(uniformColor, 1, glm::value_ptr(color));
            glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
            meshList[0]->RenderMesh();  
        }

        glUseProgram(0);
        mainWindow.swapBuffers();
    }

    return 0;
}